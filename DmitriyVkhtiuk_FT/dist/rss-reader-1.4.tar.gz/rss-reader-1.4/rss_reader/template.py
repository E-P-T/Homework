temp = '''
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
   <title>Converted version</title>
  </head>
  <body>
    {outp}
  </body>
</html>
'''